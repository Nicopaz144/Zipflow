import SwiftUI
import WebKit

struct ContentView: View {
    @State private var address = "https://gofile.io/"
    @State private var downloadURL: URL?
    @State private var message = "Abrí el sitio, buscá el archivo y tocá ‘Buscar enlace’. Si se encuentra una URL directa, podrás iniciar la descarga."
    @State private var isDownloading = false
    @State private var downloadTask: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    TextField("Dirección web o enlace", text: $address)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                        .textFieldStyle(.roundedBorder)
                    Button("Ir") { openAddress() }
                        .buttonStyle(.borderedProminent)
                }
                .padding(10)

                BrowserView(startURL: URL(string: "https://gofile.io/"), foundURL: $downloadURL, message: $message)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)

                VStack(alignment: .leading, spacing: 8) {
                    Text(message)
                        .font(.footnote)
                        .lineLimit(4)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    if let found = downloadURL {
                        Text(found.absoluteString)
                            .font(.caption2)
                            .lineLimit(2)
                            .textSelection(.enabled)
                        Button {
                            downloadTask?.cancel()
                            downloadTask = Task { await download(found) }
                        } label: {
                            HStack {
                                if isDownloading { ProgressView().tint(.white) }
                                Text(isDownloading ? "Descargando…" : "Descargar archivo detectado")
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(isDownloading)
                    }
                    Button("Buscar enlace de descarga en esta página") {
                        NotificationCenter.default.post(name: .scanDownloadLinks, object: nil)
                        message = "Buscando enlaces en la página actual… Si el sitio genera el enlace después de una confirmación, tocá primero su botón de descarga y volvé a buscar."
                    }
                    .frame(maxWidth: .infinity)
                    .buttonStyle(.bordered)
                }
                .padding(12)
                .background(.bar)
            }
            .navigationTitle("ZipFlow")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func openAddress() {
        let raw = address.trimmingCharacters(in: .whitespacesAndNewlines)
        let value = raw.contains("://") ? raw : "https://" + raw
        guard let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else {
            message = "Dirección inválida. Pegá una URL que empiece con https:// o http://."
            return
        }
        downloadURL = nil
        NotificationCenter.default.post(name: .navigateBrowser, object: url)
        message = "Abriendo página…"
    }

    @MainActor
    private func download(_ url: URL) async {
        isDownloading = true
        message = "Descargando el archivo en Archivos… No cierres la app mientras se descarga."
        defer { isDownloading = false }
        do {
            let (temporaryURL, response) = try await URLSession.shared.download(from: url)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                message = "El servidor respondió HTTP \(http.statusCode). No se guardó el archivo."
                return
            }
            let suggested = response.suggestedFilename ?? url.lastPathComponent
            let safeName = suggested.isEmpty ? "descarga.zip" : suggested
            let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            var destination = documents.appendingPathComponent(safeName)
            if FileManager.default.fileExists(atPath: destination.path) {
                destination = documents.appendingPathComponent("\(UUID().uuidString)-\(safeName)")
            }
            try FileManager.default.moveItem(at: temporaryURL, to: destination)
            message = "Descarga terminada. Archivo guardado en la carpeta Documentos de ZipFlow: \(destination.lastPathComponent). Podés abrirlo desde Archivos si la app expone sus documentos."
        } catch is CancellationError {
            message = "Descarga cancelada."
        } catch {
            message = "No se pudo descargar: \(error.localizedDescription). El enlace puede requerir una sesión o una confirmación en la web."
        }
    }
}

extension Notification.Name {
    static let navigateBrowser = Notification.Name("ZipFlowNavigateBrowser")
    static let scanDownloadLinks = Notification.Name("ZipFlowScanDownloadLinks")
}

struct BrowserView: UIViewRepresentable {
    let startURL: URL?
    @Binding var foundURL: URL?
    @Binding var message: String

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        context.coordinator.webView = webView
        if let startURL { webView.load(URLRequest(url: startURL)) }
        context.coordinator.observeNotifications()
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        var parent: BrowserView
        weak var webView: WKWebView?
        private var observers: [NSObjectProtocol] = []

        init(_ parent: BrowserView) { self.parent = parent }

        func observeNotifications() {
            observers.append(NotificationCenter.default.addObserver(forName: .navigateBrowser, object: nil, queue: .main) { [weak self] note in
                guard let url = note.object as? URL else { return }
                self?.webView?.load(URLRequest(url: url))
            })
            observers.append(NotificationCenter.default.addObserver(forName: .scanDownloadLinks, object: nil, queue: .main) { [weak self] _ in
                self?.scanLinks()
            })
        }

        deinit { observers.forEach(NotificationCenter.default.removeObserver) }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            parent.message = "Página cargada. Tocá ‘Buscar enlace de descarga’ después de localizar el archivo o activar el botón de descarga del sitio."
        }

        func scanLinks() {
            let script = """
            (() => {
              const links = Array.from(document.querySelectorAll('a[href]')).map(a => ({href:a.href, text:(a.innerText || a.textContent || '').trim()}));
              const likely = links.filter(x => /\\.zip(?:$|[?#])|download|direct|gofile\\.io\\/download/i.test(x.href + ' ' + x.text));
              return JSON.stringify(likely.slice(0, 40));
            })();
            """
            webView?.evaluateJavaScript(script) { [weak self] result, error in
                DispatchQueue.main.async {
                    guard let self else { return }
                    if let error {
                        self.parent.message = "No se pudieron analizar los enlaces: \(error.localizedDescription)"
                        return
                    }
                    guard let text = result as? String, let data = text.data(using: .utf8),
                          let items = try? JSONSerialization.jsonObject(with: data) as? [[String: String]], !items.isEmpty else {
                        self.parent.message = "No encontré enlaces de descarga visibles. Puede que el sitio genere el enlace con JavaScript o requiera pulsar su botón de descarga primero."
                        return
                    }
                    if let best = items.first(where: { ($0["href"] ?? "").lowercased().contains(".zip") }) ?? items.first,
                       let raw = best["href"], let url = URL(string: raw), ["https", "http"].contains(url.scheme?.lowercased() ?? "") {
                        self.parent.foundURL = url
                        self.parent.message = "Encontré un enlace posible: \(best["text"] ?? "descarga"). Revisá la URL antes de descargar. No todos los enlaces detectados son archivos ZIP directos."
                    }
                }
            }
        }
    }
}
