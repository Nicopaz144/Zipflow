import SwiftUI

struct ContentView: View {
    @State private var urlText = ""
    @State private var isChecking = false
    @State private var report = "Pegá una URL directa a un ZIP y tocá Diagnosticar.\n\nEsta versión comprueba la respuesta HTTP sin guardar el archivo completo."
    @State private var task: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            Form {
                Section("URL del archivo") {
                    TextField("https://servidor/archivo.zip", text: $urlText, axis: .vertical)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                    Button {
                        task?.cancel()
                        task = Task { await diagnose() }
                    } label: {
                        HStack {
                            if isChecking { ProgressView() }
                            Text(isChecking ? "Diagnosticando…" : "Diagnosticar URL")
                        }
                    }
                    .disabled(isChecking || urlText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    Button("Cancelar", role: .destructive) {
                        task?.cancel()
                        isChecking = false
                    }.disabled(!isChecking)
                }
                Section("Resultado") {
                    Text(report).font(.system(.footnote, design: .monospaced)).textSelection(.enabled)
                }
                Section("Importante") {
                    Label("ZIP real: normalmente empieza con PK", systemImage: "checkmark.seal")
                    Label("HTML de una web: no es el ZIP", systemImage: "exclamationmark.triangle")
                    Text("Esta versión diagnostica la respuesta; todavía no extrae archivos.").font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("ZipFlow")
        }
    }

    @MainActor private func setReport(_ value: String) { report = value }

    private func diagnose() async {
        await MainActor.run { isChecking = true; report = "Conectando…" }
        defer { Task { @MainActor in isChecking = false } }

        guard let url = URL(string: urlText.trimmingCharacters(in: .whitespacesAndNewlines)),
              let scheme = url.scheme?.lowercased(), ["https", "http"].contains(scheme),
              url.host != nil else {
            await setReport("URL inválida. Pegá una dirección completa que empiece con https:// o http://.")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 30
        request.setValue("application/zip, application/octet-stream, */*", forHTTPHeaderField: "Accept")
        request.setValue("ZipFlow/1.0 (iOS)", forHTTPHeaderField: "User-Agent")
        request.setValue("bytes=0-63", forHTTPHeaderField: "Range")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                await setReport("El servidor no devolvió HTTP.")
                return
            }
            let bytes = data.prefix(16).map { String(format: "%02X", $0) }.joined(separator: " ")
            let preview = String(data: data.prefix(160), encoding: .utf8)?
                .replacingOccurrences(of: "\n", with: " ")
                .replacingOccurrences(of: "\r", with: " ") ?? "(no es UTF-8)"
            let type = http.value(forHTTPHeaderField: "Content-Type") ?? "(no informado)"
            let length = http.value(forHTTPHeaderField: "Content-Length") ?? "(no informado)"
            let range = http.value(forHTTPHeaderField: "Content-Range") ?? "(no informado)"
            let accepts = http.value(forHTTPHeaderField: "Accept-Ranges") ?? "(no informado)"
            let finalURL = http.url?.absoluteString ?? "(desconocida)"
            let isZip = data.starts(with: [0x50, 0x4B, 0x03, 0x04]) ||
                        data.starts(with: [0x50, 0x4B, 0x05, 0x06]) ||
                        data.starts(with: [0x50, 0x4B, 0x07, 0x08])
            let sample = String(data: data.prefix(256), encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() ?? ""
            var result = """
            HTTP: \(http.statusCode)
            URL final: \(finalURL)
            Content-Type: \(type)
            Content-Length: \(length)
            Accept-Ranges: \(accepts)
            Content-Range: \(range)
            Primeros bytes: \(bytes)

            """
            if isZip {
                result += "RESULTADO: la respuesta comienza con firma ZIP. Es una buena señal para continuar."
            } else if sample.hasPrefix("<!doctype html") || sample.hasPrefix("<html") || type.lowercased().contains("text/html") || sample.contains("<!do") {
                result += "RESULTADO: el servidor entregó HTML, no el ZIP. Un extractor fallará con firma inválida. Revisá el enlace directo, sesión o verificación del proveedor."
            } else {
                result += "RESULTADO: no se detectó una firma ZIP al comienzo. Puede ser una respuesta de error, un rango distinto o un formato no compatible."
            }
            result += "\n\nVista previa (máx. 160 caracteres):\n\(preview)"
            await setReport(result)
        } catch is CancellationError {
            await setReport("Diagnóstico cancelado.")
        } catch {
            await setReport("Error de red: \(error.localizedDescription)")
        }
    }
}
