# ZipFlow

App SwiftUI para iOS 18 con navegador web integrado, búsqueda de enlaces de descarga visibles en la página y descarga del enlace detectado a Documentos de la app. Incluye diagnóstico inicial para el flujo de enlaces de archivo.

## Compilar en GitHub Actions

El workflow `.github/workflows/build-unsigned-ipa.yml` compila una app sin firma y publica un artefacto IPA. Una IPA sin firma necesita firmarse con SideStore/AltStore para instalarse.

## Limitaciones importantes

- El navegador no evita CAPTCHA, autenticación, cuotas ni otras restricciones del proveedor.
- La búsqueda revisa enlaces visibles (`a[href]`) en el DOM actual. No garantiza detectar enlaces que el sitio genere de otra manera, en una petición de API, dentro de un iframe protegido o después de un paso de verificación.
- La descarga guarda el archivo dentro del contenedor de ZipFlow. La versión actual NO extrae ZIP progresivamente ni descarga en segundo plano garantizado si se cierra la app.
- Probar primero con un ZIP pequeño y una URL directa que devuelva bytes ZIP, no HTML.
