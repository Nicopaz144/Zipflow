# ZipFlow — prototipo limpio

Proyecto SwiftUI para iOS 18+ que diagnostica qué entrega una URL antes de intentar tratarla como ZIP.

## Esta versión
- Acepta una URL HTTP/HTTPS.
- Hace una petición de prueba y muestra estado HTTP, URL final, tipo, tamaño, rangos y bytes iniciales.
- Detecta respuestas HTML en lugar de ZIP.
- No escribe el cuerpo completo en disco.

## Limitación honesta
Esta primera entrega es una base de diagnóstico, no una extracción progresiva terminada. Para extraer sin guardar el ZIP completo se necesita integrar y probar un lector ZIP realmente streaming, incluidos ZIP64 y data descriptors. El servidor también debe entregar bytes ZIP reales; una página HTML de GoFile no se puede descomprimir como ZIP.

## Compilar
En macOS con Xcode 16+ y XcodeGen: `brew install xcodegen`, luego `xcodegen generate` y abrir `ZipFlow.xcodeproj`. El workflow de GitHub Actions crea un IPA sin firmar para probar con el método de instalación que ya usás.
